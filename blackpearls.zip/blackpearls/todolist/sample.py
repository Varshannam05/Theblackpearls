Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/c.divya sri/OneDrive/Documents/todo.py
Menu:
1. Add Task
2. View Tasks
3. Mark as Done
4. Exit
Enter your choice: 1
Enter task description: hello
Task added successfully!
Menu:
1. Add Task
2. View Tasks
3. Mark as Done
4. Exit
Enter your choice: 3

Tasks:
1. hello
Enter task index to mark as done: 4
Invalid task index.
Menu:
1. Add Task
2. View Tasks
3. Mark as Done
4. Exit
